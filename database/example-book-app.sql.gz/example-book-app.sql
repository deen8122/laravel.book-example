-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Дек 23 2021 г., 08:37
-- Версия сервера: 5.7.29
-- Версия PHP: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `example-book-app`
--

-- --------------------------------------------------------

--
-- Структура таблицы `books`
--

CREATE TABLE `books` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `books`
--

INSERT INTO `books` (`id`, `name`, `description`, `created_at`, `updated_at`, `user_id`) VALUES
(1, 'She generally gave herself.', 'I beg your pardon!\' cried Alice again, for really I\'m quite tired of being such a very little use, as it was written to nobody, which isn\'t usual, you know.\' \'Not the same age as herself, to see the Queen. First came ten.', '2021-11-17 14:21:44', '2021-12-17 16:09:57', 4),
(2, 'Queen, and Alice, were in.', 'First, she tried to look through into the way of settling all difficulties, great or small. \'Off with his knuckles. It was so full of soup. \'There\'s certainly too much pepper in that soup!\' Alice said with some.', '2021-11-06 23:54:34', '2021-12-19 11:36:52', 2),
(3, 'WHAT? The other guests had.', 'The poor little thing grunted in reply (it had left off sneezing by this time, and was going to say,\' said the Queen, \'Really, my dear, YOU must cross-examine THIS witness.\' \'Well, if I fell off the top of his teacup and bread-and-butter, and then hurried on, Alice started to her head, she tried.', '2021-10-25 14:05:37', '2021-12-18 14:27:00', 1),
(4, 'Alice. \'Why, there they.', 'I\'d hardly finished the guinea-pigs!\' thought Alice. One of the thing yourself, some winter day, I will prosecute YOU.--Come, I\'ll take no denial; We must have a prize herself, you know,\' said the Duchess. An invitation for the moment she felt that it was over at.', '2021-11-11 09:51:17', '2021-12-04 14:03:41', 1),
(5, 'CAN all that green stuff.', 'SIT down,\' the King said, for about the reason and all must have a prize herself, you know,\' the Mock Turtle drew a long time together.\' \'Which is just the case with MINE,\' said the Caterpillar. \'Well, perhaps you were or might have.', '2021-11-05 15:50:39', '2021-12-09 15:20:52', 3),
(6, 'I\'ll set Dinah at you!\'.', 'Dormouse began in a shrill, passionate voice. \'Would YOU like cats if you please! \"William the Conqueror, whose cause was favoured by the end of the words a little, and then turned to the fifth bend, I think?\' he said to.', '2021-10-31 10:25:27', '2021-12-07 22:51:12', 2),
(7, 'Oh, how I wish I could shut.', 'Alice had not a moment that it signifies much,\' she said this she looked down at her as she was quite a conversation of it had a little shriek, and went stamping about, and make THEIR eyes bright and eager with many a strange tale, perhaps even with the next.', '2021-11-11 02:46:58', '2021-12-12 03:35:37', 4),
(8, 'And the moral of THAT.', 'NOT, being made entirely of cardboard.) \'All right, so far,\' said the March Hare. \'Exactly so,\' said Alice. \'I\'m a--I\'m a--\' \'Well! WHAT are you?\' And then a voice outside, and stopped to listen. \'Mary Ann! Mary Ann!\' said the Duchess, \'as pigs have to turn into a tree. \'Did you say \"What a.', '2021-11-19 11:31:21', '2021-12-15 06:13:49', 3),
(9, 'White Rabbit, who was.', 'Gryphon, sighing in his throat,\' said the King, and the little door, had vanished completely. Very soon the Rabbit say to itself, \'Oh dear! Oh dear! I shall have to fly; and the little dears came jumping merrily along hand in.', '2021-11-08 12:07:46', '2021-12-16 08:54:03', 3),
(10, 'Mouse, do you want to go!.', 'Alice, who was peeping anxiously into its eyes again, to see that she was walking hand in hand, in couples: they were all shaped like the largest telescope that ever was! Good-bye, feet!\' (for when.', '2021-11-02 09:37:16', '2021-12-16 04:59:56', 2),
(20, 'Target class [App\\Http\\Controllers\\Auth\\Request] does not exist', 'NOT, being made entirely of cardboard.) \'All right, so far,\' said the March Hare. \'Exactly so,\' said Alice. \'I\'m a--I\'m a--\' \'Well! WHAT are you?\' And then a voice outside, and stopped to listen. \'Mary Ann! Mary Ann!\' said the Duchess, \'as pigs have to turn into a tree. \'Did you say \"What a.NOT, being made entirely of cardboard.) \'All right, so far,\' said the March Hare. \'Exactly so,\' said Alice. \'I\'m a--I\'m a--\' \'Well! WHAT are you?\' And then a voice outside, and stopped to listen. \'Mary Ann! Mary Ann!\' said the Duchess, \'as pigs have to turn into a tree. \'Did you say \"What a.', '2021-12-22 10:52:15', '2021-12-22 10:52:15', 9);

-- --------------------------------------------------------

--
-- Структура таблицы `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2021_12_22_111944_create_books_table', 2),
(6, '2021_12_22_174659_create_jobs_table', 3);

-- --------------------------------------------------------

--
-- Структура таблицы `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Mr. Barry Christiansen', 'kerluke.jacquelyn@example.org', '2021-12-22 07:24:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'FQbQxI9fHB', '2021-12-22 07:24:41', '2021-12-22 07:24:41'),
(2, 'Salvador Stracke', 'lottie60@example.com', '2021-12-22 07:24:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'xLCePy4lZJ', '2021-12-22 07:24:41', '2021-12-22 07:24:41'),
(3, 'Bradly Walter', 'kaela02@example.com', '2021-12-22 07:24:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'HWSwXQd7Fj', '2021-12-22 07:24:41', '2021-12-22 07:24:41'),
(4, 'Dr. Forrest Erdman DDS', 'rasheed.cole@example.org', '2021-12-22 07:24:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'J5pTXlRPVS', '2021-12-22 07:24:41', '2021-12-22 07:24:41'),
(5, 'Will Dibbert', 'scotty.mcdermott@example.net', '2021-12-22 07:25:16', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'SmUUF7krXP', '2021-12-22 07:25:16', '2021-12-22 07:25:16'),
(6, 'Clarissa Lindgren', 'quinn32@example.net', '2021-12-22 07:25:16', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'r5DC3uSEQN', '2021-12-22 07:25:16', '2021-12-22 07:25:16'),
(7, 'Miss Kenyatta Hermann', 'ciara83@example.net', '2021-12-22 07:25:16', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'CrBj3QOuiI', '2021-12-22 07:25:16', '2021-12-22 07:25:16'),
(8, 'Dr. Veronica Runte II', 'kgreenfelder@example.org', '2021-12-22 07:25:16', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'aEcXnRWaxt', '2021-12-22 07:25:16', '2021-12-22 07:25:16'),
(9, 'Динис Кагарманов', 'deen812@mail.ru', NULL, '$2y$10$Ed/Q2sWQvu37Po3/71hAwOQjNdFRKKicCRUcFkIlpDoGS3fTIvW6u', NULL, '2021-12-22 09:19:57', '2021-12-22 09:19:57'),
(10, 'deen8122@mail.ru', 'deen8122@mail.ru', NULL, '$2y$10$axseqKmL9Voob/etxqF7CeEmC9Mv6Q7hHplXjO6YyRMYu7mjBkyfK', NULL, '2021-12-22 10:55:26', '2021-12-22 10:55:26');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`),
  ADD KEY `books_user_id_foreign` (`user_id`);

--
-- Индексы таблицы `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Индексы таблицы `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Индексы таблицы `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Индексы таблицы `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `books`
--
ALTER TABLE `books`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT для таблицы `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT для таблицы `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=228;

--
-- AUTO_INCREMENT для таблицы `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `books`
--
ALTER TABLE `books`
  ADD CONSTRAINT `books_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
